package com.hieu.demojpa.entity;

import java.io.Serializable;

public class ShoppingCartItem implements Serializable {
    public Products product;
    public int Qty;
}
