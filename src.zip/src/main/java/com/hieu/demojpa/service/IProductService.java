package com.hieu.demojpa.service;

public interface IProductService {
}
