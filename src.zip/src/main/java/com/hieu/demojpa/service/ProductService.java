package com.hieu.demojpa.service;

import org.springframework.stereotype.Service;

@Service
public class ProductService implements IProductService{
}
